import React from 'react';
import { Info, AlertCircle, CheckCircle2 } from 'lucide-react';

const Instructions: React.FC = () => {
  return (
    <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-6 w-full">
      <div className="flex items-center mb-4">
        <Info className="h-5 w-5 mr-2 text-black" />
        <h2 className="text-lg font-medium">How to use LinkBypass</h2>
      </div>
      
      <div className="space-y-4">
        <div className="flex">
          <div className="mr-3 flex-shrink-0">
            <div className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-black text-black">
              1
            </div>
          </div>
          <div>
            <p className="text-sm">
              Paste the URL you want to bypass in the input field above.
            </p>
          </div>
        </div>
        
        <div className="flex">
          <div className="mr-3 flex-shrink-0">
            <div className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-black text-black">
              2
            </div>
          </div>
          <div>
            <p className="text-sm">
              Click the "Bypass URL" button and wait for the result.
            </p>
          </div>
        </div>
        
        <div className="flex">
          <div className="mr-3 flex-shrink-0">
            <div className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-black text-black">
              3
            </div>
          </div>
          <div>
            <p className="text-sm">
              Copy the bypassed URL or click to open it directly.
            </p>
          </div>
        </div>
      </div>
      
      <div className="mt-6 flex items-start">
        <AlertCircle className="h-5 w-5 mr-2 text-gray-500 flex-shrink-0 mt-0.5" />
        <p className="text-sm text-gray-600">
          Our service works with many popular URL shorteners and redirect services.
          If you encounter any issues, please try a different URL.
        </p>
      </div>
      
      <div className="mt-4 flex items-start">
        <CheckCircle2 className="h-5 w-5 mr-2 text-gray-500 flex-shrink-0 mt-0.5" />
        <p className="text-sm text-gray-600">
          LinkBypass respects your privacy. We don't store your bypassed URLs on our servers.
        </p>
      </div>
    </div>
  );
};

export default Instructions;