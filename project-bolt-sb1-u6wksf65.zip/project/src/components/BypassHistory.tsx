import React from 'react';
import { ClockRewind, Trash2 } from 'lucide-react';

interface HistoryItem {
  id: string;
  originalUrl: string;
  bypassedUrl: string;
  timestamp: number;
}

interface BypassHistoryProps {
  history: HistoryItem[];
  onSelect: (item: HistoryItem) => void;
  onClear: () => void;
  onRemove: (id: string) => void;
}

const BypassHistory: React.FC<BypassHistoryProps> = ({ 
  history, 
  onSelect, 
  onClear,
  onRemove
}) => {
  if (history.length === 0) {
    return null;
  }

  return (
    <div className="w-full mt-8">
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center">
          <ClockRewind className="h-5 w-5 mr-2" />
          <h3 className="text-lg font-medium">Recent Bypasses</h3>
        </div>
        <button
          onClick={onClear}
          className="text-sm text-gray-500 hover:text-black transition-colors duration-200"
        >
          Clear All
        </button>
      </div>
      <div className="space-y-2">
        {history.map((item) => (
          <div 
            key={item.id}
            className="flex justify-between items-center p-3 bg-gray-50 border border-gray-200 rounded-md hover:bg-gray-100 transition-colors duration-200"
          >
            <div className="flex-1 truncate mr-4" onClick={() => onSelect(item)}>
              <p className="text-sm font-medium truncate cursor-pointer hover:underline">
                {item.originalUrl}
              </p>
              <p className="text-xs text-gray-500">
                {new Date(item.timestamp).toLocaleString()}
              </p>
            </div>
            <button
              onClick={() => onRemove(item.id)}
              className="p-1 text-gray-400 hover:text-gray-600 transition-colors duration-200"
              aria-label="Remove from history"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BypassHistory;