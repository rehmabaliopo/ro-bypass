import React, { useState } from 'react';
import { Copy, Check, ExternalLink } from 'lucide-react';
import Button from './Button';

interface ResultCardProps {
  originalUrl: string;
  bypassedUrl: string;
}

const ResultCard: React.FC<ResultCardProps> = ({ originalUrl, bypassedUrl }) => {
  const [copied, setCopied] = useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(bypassedUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm p-6 mb-4 w-full">
      <h3 className="text-lg font-medium mb-4">Bypass Result</h3>
      
      <div className="mb-4">
        <p className="text-sm text-gray-500 mb-1">Original URL:</p>
        <div className="p-3 bg-gray-100 rounded-md text-sm break-all">
          {originalUrl}
        </div>
      </div>
      
      <div className="mb-4">
        <p className="text-sm text-gray-500 mb-1">Bypassed URL:</p>
        <div className="p-3 bg-gray-100 rounded-md text-sm break-all">
          {bypassedUrl}
        </div>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-3">
        <Button 
          variant="primary" 
          onClick={copyToClipboard}
          className="flex-1"
        >
          {copied ? (
            <>
              <Check className="h-4 w-4 mr-2" />
              Copied!
            </>
          ) : (
            <>
              <Copy className="h-4 w-4 mr-2" />
              Copy URL
            </>
          )}
        </Button>
        <Button 
          variant="outline"
          onClick={() => window.open(bypassedUrl, '_blank')}
          className="flex-1"
        >
          <ExternalLink className="h-4 w-4 mr-2" />
          Open URL
        </Button>
      </div>
    </div>
  );
};

export default ResultCard;