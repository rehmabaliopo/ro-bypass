import React, { useState } from 'react';
import Button from './Button';
import { bypassUrl } from '../utils/bypass';

interface BypassFormProps {
  onBypassComplete: (originalUrl: string, bypassedUrl: string) => void;
  setError: (error: string | null) => void;
}

const BypassForm: React.FC<BypassFormProps> = ({ onBypassComplete, setError }) => {
  const [url, setUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!url.trim()) {
      setError('Please enter a URL to bypass');
      return;
    }

    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      setError('Please enter a valid URL starting with http:// or https://');
      return;
    }

    try {
      setError(null);
      setIsLoading(true);
      const result = await bypassUrl(url);
      onBypassComplete(url, result);
      setUrl('');
    } catch (error) {
      setError('Error bypassing URL. Please try again.');
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full">
      <div className="flex flex-col space-y-4">
        <label htmlFor="url-input" className="text-sm font-medium text-gray-700">
          Enter URL to bypass:
        </label>
        <input
          id="url-input"
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://example.com/redirect?url=..."
          className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-black focus:border-black"
        />
        <Button
          type="submit"
          isLoading={isLoading}
          className="w-full py-3"
        >
          Bypass URL
        </Button>
      </div>
    </form>
  );
};

export default BypassForm;