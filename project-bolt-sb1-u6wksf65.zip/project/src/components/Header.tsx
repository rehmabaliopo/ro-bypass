import React from 'react';
import { ExternalLink } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="w-full bg-black text-white py-4 px-6 shadow-md">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <ExternalLink className="h-6 w-6" />
          <h1 className="text-xl font-bold">LinkBypass</h1>
        </div>
        <nav>
          <ul className="flex space-x-6">
            <li>
              <a href="#" className="hover:text-gray-300 transition-colors duration-200">
                Home
              </a>
            </li>
            <li>
              <a href="#" className="hover:text-gray-300 transition-colors duration-200">
                About
              </a>
            </li>
            <li>
              <a href="#" className="hover:text-gray-300 transition-colors duration-200">
                FAQ
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;