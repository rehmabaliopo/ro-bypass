import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import BypassForm from './components/BypassForm';
import ResultCard from './components/ResultCard';
import BypassHistory from './components/BypassHistory';
import Instructions from './components/Instructions';
import { AlertCircle } from 'lucide-react';

interface HistoryItem {
  id: string;
  originalUrl: string;
  bypassedUrl: string;
  timestamp: number;
}

function App() {
  const [result, setResult] = useState<{ original: string; bypassed: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    const savedHistory = localStorage.getItem('bypass-history');
    return savedHistory ? JSON.parse(savedHistory) : [];
  });

  useEffect(() => {
    localStorage.setItem('bypass-history', JSON.stringify(history));
  }, [history]);

  const handleBypassComplete = (originalUrl: string, bypassedUrl: string) => {
    setResult({ original: originalUrl, bypassed: bypassedUrl });
    
    const newHistoryItem: HistoryItem = {
      id: Date.now().toString(),
      originalUrl,
      bypassedUrl,
      timestamp: Date.now()
    };
    
    setHistory(prev => [newHistoryItem, ...prev.slice(0, 9)]);
  };

  const handleHistorySelect = (item: HistoryItem) => {
    setResult({ original: item.originalUrl, bypassed: item.bypassedUrl });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleHistoryClear = () => {
    setHistory([]);
  };

  const handleHistoryRemove = (id: string) => {
    setHistory(prev => prev.filter(item => item.id !== id));
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8 md:px-6 max-w-4xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-3">URL Bypasser</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Instantly bypass URL shorteners, ad pages, and redirect links to get direct access to your destination.
          </p>
        </div>
        
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm p-6 mb-6">
          <BypassForm
            onBypassComplete={handleBypassComplete}
            setError={setError}
          />
          
          {error && (
            <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-md flex items-start">
              <AlertCircle className="h-5 w-5 text-red-500 mt-0.5 mr-2 flex-shrink-0" />
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}
        </div>
        
        {result && (
          <ResultCard
            originalUrl={result.original}
            bypassedUrl={result.bypassed}
          />
        )}
        
        <Instructions />
        
        <BypassHistory
          history={history}
          onSelect={handleHistorySelect}
          onClear={handleHistoryClear}
          onRemove={handleHistoryRemove}
        />
      </main>
      
      <Footer />
    </div>
  );
}

export default App;